# This function is here because the argument of gamma function does not accept the a vector!
Γ(b) = map(gamma, b)
